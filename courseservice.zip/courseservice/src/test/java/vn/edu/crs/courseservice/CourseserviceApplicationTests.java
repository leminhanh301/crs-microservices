package vn.edu.crs.courseservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
